package com.example.dell.toureiffel;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * {@link Fragment} that displays a list of Parks
 */
public class ParksFragment extends Fragment {

    public ParksFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.element_list, container, false);

        // Create a list of monuments
        final ArrayList<Element> elements = new ArrayList<>();
        elements.add(new Element(getString(R.string.a_19), getString(R.string.buttes_chaumont), R.drawable.parc_chaumont, getString(R.string.t_1)));
        elements.add(new Element(getString(R.string.a_8), getString(R.string.monceau), R.drawable.parc_monceau, getString(R.string.t_2)));
        elements.add(new Element(getString(R.string.a_14), getString(R.string.montsouris), R.drawable.parc_montsouris, getString(R.string.t_3)));
        elements.add(new Element(getString(R.string.a_20), getString(R.string.belleville), R.drawable.parc_belleville, getString(R.string.t_4)));
        elements.add(new Element(getString(R.string.a_16), getString(R.string.boulogne), R.drawable.bois_boulogne, getString(R.string.t_5)));
        elements.add(new Element(getString(R.string.a_13), getString(R.string.choisy), R.drawable.parc_choisy, getString(R.string.t_6)));
        elements.add(new Element(getString(R.string.a_15), getString(R.string.brassens), R.drawable.parc_brassens, getString(R.string.t_7)));
        elements.add(new Element(getString(R.string.a_12), getString(R.string.bercy), R.drawable.parc_bercy, getString(R.string.t_8)));
        elements.add(new Element(getString(R.string.a_15), getString(R.string.atlantique), R.drawable.jardin_atlantique, getString(R.string.t_9)));
        elements.add(new Element(getString(R.string.a_1), getString(R.string.tuileries), R.drawable.jardin_tuilleries, getString(R.string.t_10)));

        ElementAdapter adapter = new ElementAdapter(getActivity(), elements);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);

        return rootView;
    }
}