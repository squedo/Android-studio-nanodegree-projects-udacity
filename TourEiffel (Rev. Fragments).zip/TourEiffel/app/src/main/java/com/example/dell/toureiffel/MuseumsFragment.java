package com.example.dell.toureiffel;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * {@link Fragment} that displays a list of museums
 */
public class MuseumsFragment extends Fragment {

    public MuseumsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.element_list, container, false);

        // Create a list of monuments
        final ArrayList<Element> elements = new ArrayList<>();
        elements.add(new Element(getString(R.string.a_1), getString(R.string.louvre), R.drawable.palais_du_louvre, getString(R.string.p_1)));
        elements.add(new Element(getString(R.string.a_7), getString(R.string.orsay), R.drawable.musee_orsay, getString(R.string.p_2)));
        elements.add(new Element(getString(R.string.a_3), getString(R.string.picasso), R.drawable.musee_picasso, getString(R.string.p_3)));
        elements.add(new Element(getString(R.string.a_4), getString(R.string.pompidou), R.drawable.centre_pompidou, getString(R.string.p_4)));
        elements.add(new Element(getString(R.string.a_5), getString(R.string.curie), R.drawable.musee_curie, getString(R.string.p_5)));
        elements.add(new Element(getString(R.string.a_1), getString(R.string.orangerie), R.drawable.musee_orangerie, getString(R.string.p_6)));
        elements.add(new Element(getString(R.string.a_16), getString(R.string.vin), R.drawable.musee_du_vin, getString(R.string.p_7)));
        elements.add(new Element(getString(R.string.a_11), getString(R.string.piaf), R.drawable.maison_piaf, getString(R.string.p_8)));
        elements.add(new Element(getString(R.string.a_4), getString(R.string.hugo), R.drawable.maison_hugo, getString(R.string.p_9)));
        elements.add(new Element(getString(R.string.a_16), getString(R.string.barlzac), R.drawable.maison_balzac, getString(R.string.p_10)));

        ElementAdapter adapter = new ElementAdapter(getActivity(), elements);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);

        return rootView;
    }
}