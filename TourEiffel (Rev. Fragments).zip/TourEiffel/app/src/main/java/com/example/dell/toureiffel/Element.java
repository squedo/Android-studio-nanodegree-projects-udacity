package com.example.dell.toureiffel;

public class Element {

    //Arrondissement number
    private String mArrondissementNumber;

    //Name
    private String mName;

    //Image resource ID for the word
    private int mImageResourceID;

    //Information
    private String mInfo;

    public Element(String arrondissementNumber, String name, int imageResourceID, String info) {
        mArrondissementNumber = arrondissementNumber;
        mName = name;
        mImageResourceID = imageResourceID;
        mInfo = info;
    }

    //Get the arrondissement number
    public String getArrondissementNumber (){
        return mArrondissementNumber;
    }

    //Get the name
    public String getName(){ return mName;}

    //Get the image resource ID for the word
    public int getImageResourceID (){ return mImageResourceID; }

    //Get the other info
    public String getInfo(){ return mInfo;}

}
