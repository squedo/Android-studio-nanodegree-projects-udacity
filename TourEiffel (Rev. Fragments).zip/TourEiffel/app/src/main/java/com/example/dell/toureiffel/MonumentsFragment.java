package com.example.dell.toureiffel;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * {@link Fragment} that displays a list of monuments
 */
public class MonumentsFragment extends Fragment {

    public MonumentsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.element_list, container, false);

        // Create a list of monuments
        final ArrayList<Element> elements = new ArrayList<>();
        elements.add(new Element(getString(R.string.a_7), getString(R.string.eiffel), R.drawable.tour_eiffel, getString(R.string.f_1)));
        elements.add(new Element(getString(R.string.a_4), getString(R.string.notre_dame), R.drawable.notre_dame, getString(R.string.f_2)));
        elements.add(new Element(getString(R.string.a_8), getString(R.string.triomphe), R.drawable.arc_de_triomphe, getString(R.string.f_3)));
        elements.add(new Element(getString(R.string.a_1), getString(R.string.louvre), R.drawable.palais_du_louvre, getString(R.string.f_4)));
        elements.add(new Element(getString(R.string.a_18), getString(R.string.sacre_coeur), R.drawable.sacre_coeur, getString(R.string.f_5)));
        elements.add(new Element(getString(R.string.a_5), getString(R.string.panteon), R.drawable.pantheon, getString(R.string.f_6)));
        elements.add(new Element(getString(R.string.a_9), getString(R.string.opera), R.drawable.opera_garnier, getString(R.string.f_7)));
        elements.add(new Element(getString(R.string.a_7), getString(R.string.invalides), R.drawable.les_invalides, getString(R.string.f_8)));
        elements.add(new Element(getString(R.string.a_4), getString(R.string.pompidou), R.drawable.centre_pompidou, getString(R.string.f_9)));
        elements.add(new Element(getString(R.string.a_6), getString(R.string.palais_luxembourg), R.drawable.palais_du_luxembourg, getString(R.string.f_10)));


        ElementAdapter adapter = new ElementAdapter(getActivity(), elements);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);

        return rootView;

    }
}

