package com.example.dell.toureiffel;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ElementAdapter extends ArrayAdapter<Element> {


    public ElementAdapter(Context context, ArrayList<Element> elements) {
        super(context, 0, elements);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.item_list, parent, false);
        }

        Element currentElement = getItem(position);

        TextView arrondissementNumberTextView = (TextView) listItemView.findViewById(R.id.arrondissement_number);
        arrondissementNumberTextView.setText(currentElement.getArrondissementNumber());

        TextView nameTextView = (TextView) listItemView.findViewById(R.id.name);
        nameTextView.setText(currentElement.getName());

        ImageView imageResourceID = (ImageView) listItemView.findViewById(R.id.item_list_imageview);
        imageResourceID.setImageResource(currentElement.getImageResourceID());

        TextView infoTextView = (TextView) listItemView.findViewById(R.id.info_textview);
        infoTextView.setText(currentElement.getInfo());

        //Return the whole list item layout so that it can be shown in the ListView
        return listItemView;
    }
}
