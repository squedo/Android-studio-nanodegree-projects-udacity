package com.example.dell.toureiffel;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * {@link Fragment} that displays a list of events
 */
public class EventsFragment extends Fragment {

    public EventsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.element_list, container, false);

        // Create a list of monuments
        final ArrayList<Element> elements = new ArrayList<>();
        elements.add(new Element(getString(R.string.a_11), getString(R.string.fashion_week), R.drawable.fashion_week, getString(R.string.date_1)));
        elements.add(new Element(getString(R.string.a_20), getString(R.string.carnaval), R.drawable.carnaval, getString(R.string.date_2)));
        elements.add(new Element(getString(R.string.City), getString(R.string.halfmarathon), R.drawable.half_marathon, getString(R.string.date_3)));
        elements.add(new Element(getString(R.string.City), getString(R.string.saint_patrick), R.drawable.saint_patrick, getString(R.string.date_4)));
        elements.add(new Element(getString(R.string.City), getString(R.string.marathon), R.drawable.marathon, getString(R.string.date_5)));
        elements.add(new Element(getString(R.string.a_15), getString(R.string.foire), R.drawable.foire_paris, getString(R.string.date_6)));
        elements.add(new Element(getString(R.string.a_16), getString(R.string.roland_garros), R.drawable.roland_garros, getString(R.string.date_7)));
        elements.add(new Element(getString(R.string.a_12), getString(R.string.jazz_fest), R.drawable.jazz_festival, getString(R.string.date_8)));
        elements.add(new Element(getString(R.string.City), getString(R.string.paris_plage), R.drawable.paris_plage, getString(R.string.date_9)));
        elements.add(new Element(getString(R.string.a_111819), getString(R.string.rock_seine), R.drawable.rock_en_seine,getString(R.string.date_10)));

        ElementAdapter adapter = new ElementAdapter(getActivity(), elements);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);

        return rootView;
    }
}